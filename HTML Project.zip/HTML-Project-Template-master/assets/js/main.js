import Foo from './foo_class.js';

const foo = new Foo();

console.log(foo.bar());
console.log('Hello, world!');
//# sourceMappingURL=main.js.map
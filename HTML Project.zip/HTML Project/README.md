# HTML Project Template

This is my HTML project template. I use this as a starting point whenever I want to quickly play with an idea within [VS Code](https://code.visualstudio.com/).

I tend to use the template files with the VS Code [Live Server extension](https://github.com/ritwickdey/vscode-live-server) to provide a local [CodePen](https://codepen.io/)-esque experience.
